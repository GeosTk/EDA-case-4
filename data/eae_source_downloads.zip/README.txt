EAE source downloads supporting Case Study 4

This package contains the exact nine resources downloaded from the live Energy
Access Explorer API and its linked public storage for the analysis. Their UTC
retrieval timestamps, URLs and SHA-256 hashes are in download_manifest.jsonl.

Contents
  raw/health-facilities.geojson       National facility points and attributes
  raw/districts.geojson               District boundaries
  raw/population.tif                  Population raster
  raw/distribution-distance.tif       Proximity to distribution infrastructure
  raw/wealth.tif                      Relative wealth raster
  raw/solar-ghi.tif                   Solar-resource raster
  raw/uganda-datasets.json            Source metadata, vintages and licences
  raw/uganda-geographies.json         Geography definitions
  raw/selected-categories.json        Layer units and native analysis definitions
  download_manifest.jsonl             Exact download provenance
  sources.json                       Attribution and cost-source interpretation

Export status
These are raw EAE source downloads. The website's native analysis-export package
(PowerPoint, priority CSVs and index TIFF) requires EAE account sign-in and was
not an input to the reported funding ranking. The final ranking, named awards
and sensitivity tables are independent calculations provided in outputs/ in
the repository. They must not be described as EAE-generated district ANI data.

Reproducibility
https://github.com/GeosTk/EDA-case-4
Run src/analyse.py using the supplied source snapshot and config.json.
The report explains the distinction between website exploration and the
facility-specific scoring extension. Original data-owner terms apply; see
raw/uganda-datasets.json and sources.json.
